class UserModel {
  String name = " ";
  String message = " ";
  String time = " ";
  String avatar = " ";
  UserModel(
      {required this.name,
      required this.message,
      required this.time,
      required this.avatar});
}

List<UserModel> chatData = [
  UserModel(
    name: "Anisha",
    message: "Hello di! k chha khabar",
    time: "11:11",
    avatar: "images/noimage.png",
  ),
  UserModel(
    name: "Manisha",
    message: "Hello",
    time: "12:11",
    avatar: "images/manisha.jpg",
  ),
  UserModel(
    name: "Rakhi",
    message: "Hey girl!",
    time: "1:11",
    avatar: "images/rakhi.jpg",
  ),
  UserModel(
    name: "Sahid",
    message: "Pick up the call",
    time: "12:11",
    avatar: "images/sahid.jpg",
  ),
  UserModel(
    name: "Katrina",
    message: "Sorry",
    time: "12:11",
    avatar: "images/kat.jpg",
  ),
  UserModel(
    name: "Kylie",
    message: "I am sorry",
    time: "12:11",
    avatar: "images/kylie.jpg",
  ),
  UserModel(
    name: "Elon Musk",
    message: "You are hired!",
    time: "3:11",
    avatar: "images/elon.jpg",
  ),
  UserModel(
    name: "Bill Gates",
    message: "We are divorced.",
    time: "4:11",
    avatar: "images/bill.jpg",
  ),
  UserModel(
    name: "Mukesh",
    message: "Give me 1 billion dollars",
    time: "2:11",
    avatar: "images/mukesh.jpg",
  ),
  UserModel(
    name: "Barak",
    message: "Hello",
    time: "10:11",
    avatar: "images/barak.jpg",
  ),
];
// chatData = ChatModel()
