import "package:flutter/material.dart";

class ChatModel {
  String name = " ";
  String time = " ";
  String avatar = " ";
  ChatModel(
      {required this.name,
      required this.time,
      required this.avatar});
}

List<ChatModel> chatData = [
  ChatModel(
    name: "Anisha",
    time: "11:11",
    avatar: "images/noimage.png",
  ),
 ChatModel(
    name: "Manisha",
    time: "12:11",
    avatar: "images/manisha.jpg",
  ),
  ChatModel(
    name: "Rakhi",  
    time: "1:11",
    avatar: "images/rakhi.jpg",
  ),
  ChatModel(
    name: "Sahid",
    time: "12:11",
    avatar: "images/sahid.jpg",
  ),
  ChatModel(
    name: "Katrina", 
    time: "12:11",
    avatar: "images/kat.jpg",
  ),
  ChatModel(
    name: "Elon Musk",  
    time: "3:11",
    avatar: "images/elon.jpg",
  ),
];
// chatData = ChatModel()
