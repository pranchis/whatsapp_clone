import 'package:flutter/material.dart';
import 'package:whatsapp_ui/pages/StatusPage.dart';
import 'package:whatsapp_ui/pages/callpage.dart';
import 'package:whatsapp_ui/pages/chatpages.dart';

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final List<Tab> topTabs = <Tab>[
    Tab(icon: Icon(Icons.camera_alt)),
    Tab(text: 'CHATS'),
    Tab(text: 'STATUS'),
    Tab(text: 'CALLS'),
  ];

  @override
  void initState() {
    _tabController = TabController(length: 4, initialIndex: 1, vsync: this)
      ..addListener(() {
        setState(() {});
      });
    super.initState();
  }

  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          // Here we take the value from the MyHomePage object that was created by
          // the App.build method, and use it to set our appbar title.
          title: Text(widget.title),
          actions: [
            IconButton(
                icon: Icon(Icons.search),
                onPressed: () {
                  print('Search Button Clicked');
                }),
            IconButton(
                icon: Icon(Icons.more_vert),
                onPressed: () {
                  print('Three dot Button Clicked');
                }),
          ],
          bottom: TabBar(
            controller: _tabController,
            indicatorColor: Colors.white,
            tabs: topTabs,
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            Text('Camera'),
            Chatpage(),
            StatusPage(),
            CallPage(),
          ],
        ));
  }
}
